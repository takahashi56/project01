<?php
$distinfo = array(
'70fc7682d5f94596ae482418b8d00ffc7ed6ec60' => MODULE_REALDIR . 'mdl_alij_213/card.php',
'adbc92c1bb3adaee0e2185344c4c958498b7614f' => MODULE_REALDIR . 'mdl_alij_213/mdl_alij.php',
'a7c01652c917c22c807dc4e088dfccb083812c23' => MODULE_REALDIR . 'mdl_alij_213/.project',
'c40e35bc60ea6680d5a923fd7933bf6b6e66b60a' => MODULE_REALDIR . 'mdl_alij_213/class/LC_Mdl_ALIJ.php',
'19d988f05576199b7f456b8577d6d05d0e924265' => MODULE_REALDIR . 'mdl_alij_213/class/pages/LC_Page_Mdl_ALIJ_Config.php',
'0f0e845720ea8d0a47ce4249893bf5f202824ea6' => MODULE_REALDIR . 'mdl_alij_213/mdl_alij_settlement.php',
'552f4bc6c74c74a0789a1e03cfae1ba56e562d68' => MODULE_REALDIR . 'mdl_alij_213/inc/include.php',
'5a96ef817b3f1d893420d924f6769341df152290' => MODULE_REALDIR . 'mdl_alij_213/copy/alij_recv.php',
'2d2fd58f6ab386b9323311edbb93727a5085cbce' => MODULE_REALDIR . 'mdl_alij_213/config.php',
'0914a3945f204bab50232f9ffe6f907c7fd1d864' => MODULE_REALDIR . 'mdl_alij_213/index.php',
'df7dd8ef26a3d569d554541c0a1fd0c96b46b04a' => MODULE_REALDIR . 'mdl_alij_213/templates/card_sphone.tpl',
'f19f8e391d5058cada927edf04114a483b546ba7' => MODULE_REALDIR . 'mdl_alij_213/templates/config.tpl',
'05f7acbfd4841e37ea27e5708590f4dba90b8126' => MODULE_REALDIR . 'mdl_alij_213/templates/card_pc.tpl',
'ce03b378e2437a5e0976fc9e26c14dc31167fa8e' => MODULE_REALDIR . 'mdl_alij_213/templates/card_mobile.tpl',
);
